# RJ Game
A simple real money betting game frontend + backend (Node.js).

## How to run
1. `cd backend`
2. `npm install express`
3. `node server.js`