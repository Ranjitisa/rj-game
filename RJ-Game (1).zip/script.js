function play() {
  alert("Game started!");
}